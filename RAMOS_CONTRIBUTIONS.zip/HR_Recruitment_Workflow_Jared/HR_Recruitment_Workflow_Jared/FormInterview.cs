﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace HR_Recruitment_Workflow_Jared
{
    public partial class FormInterview : Form
    {
        
        DatabaseConnection db = new DatabaseConnection();

        public FormInterview()
        {
            InitializeComponent();
        }

        private void btnSchedule_Click(object sender, EventArgs e)
        {
           
            if (string.IsNullOrWhiteSpace(txtAppID.Text) || string.IsNullOrWhiteSpace(txtInterviewer.Text))
            {
                MessageBox.Show("Please enter the Application ID and the Interviewer's name.", "Missing Data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int appID = Convert.ToInt32(txtAppID.Text);

            
            DateTime interviewDate = dtpInterviewDate.Value;
            string interviewer = txtInterviewer.Text;

            try
            {
                using (MySqlConnection conn = db.GetConnection())
                {
                    conn.Open();

                    
                    string insertInterview = "INSERT INTO InterviewSchedules (ApplicationID, InterviewDate, Interviewer, Status) VALUES (@AppID, @Date, @Interviewer, 'Scheduled')";
                    MySqlCommand cmdInterview = new MySqlCommand(insertInterview, conn);
                    cmdInterview.Parameters.AddWithValue("@AppID", appID);
                    cmdInterview.Parameters.AddWithValue("@Date", interviewDate);
                    cmdInterview.Parameters.AddWithValue("@Interviewer", interviewer);
                    cmdInterview.ExecuteNonQuery();

                    
                    string updateApp = "UPDATE Applications SET Status = 'Interview Scheduled' WHERE ApplicationID = @AppID";
                    MySqlCommand cmdUpdate = new MySqlCommand(updateApp, conn);
                    cmdUpdate.Parameters.AddWithValue("@AppID", appID);
                    cmdUpdate.ExecuteNonQuery();

                    
                    string historyQuery = "INSERT INTO ApplicationStatusHistory (ApplicationID, NewStatus, ChangedBy, Remarks) VALUES (@AppID, 'Interview Scheduled', 'HR Staff', 'Scheduled interview with: ' + @Interviewer)";
                    MySqlCommand histCmd = new MySqlCommand(historyQuery, conn);
                    histCmd.Parameters.AddWithValue("@AppID", appID);
                    histCmd.Parameters.AddWithValue("@Interviewer", interviewer);
                    histCmd.ExecuteNonQuery();

                    MessageBox.Show("Interview scheduled successfully! Status updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    
                    txtAppID.Clear();
                    txtInterviewer.Clear();
                    dtpInterviewDate.Value = DateTime.Now;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}