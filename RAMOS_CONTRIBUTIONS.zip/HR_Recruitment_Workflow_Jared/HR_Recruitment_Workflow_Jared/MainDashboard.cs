﻿using System;
using System.Windows.Forms;

namespace HR_Recruitment_Workflow_Jared
{
    public partial class MainDashboard : Form
    {
        public MainDashboard()
        {
            InitializeComponent();
        }

        private void MainDashboard_Load(object sender, EventArgs e)
        {
            
        }

        private void btnOpenList_Click_1(object sender, EventArgs e)
        {
            
            Form1 listForm = new Form1();
            listForm.Show();
        }

        private void btnOpenScreening_Click_1(object sender, EventArgs e)
        {
            
            FormScreening screeningForm = new FormScreening();
            screeningForm.Show();
        }

        private void btnOpenInterview_Click_1(object sender, EventArgs e)
        {
            
            FormInterview interviewForm = new FormInterview();
            interviewForm.Show();
        }

        private void btnOpenEvaluation_Click(object sender, EventArgs e)
        {
            FormInterviewEvaluation evalForm = new FormInterviewEvaluation();
            evalForm.Show();
        }

        private void btnOpenReview_Click(object sender, EventArgs e)
        {
            FormApplicantReview reviewForm = new FormApplicantReview();
            reviewForm.Show();
        }
    }
}