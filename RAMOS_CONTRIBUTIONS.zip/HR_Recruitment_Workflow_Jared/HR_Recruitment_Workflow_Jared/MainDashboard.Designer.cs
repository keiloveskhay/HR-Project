﻿namespace HR_Recruitment_Workflow_Jared
{
    partial class MainDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnOpenList = new Button();
            btnOpenScreening = new Button();
            btnOpenInterview = new Button();
            btnOpenEvaluation = new Button();
            btnOpenReview = new Button();
            SuspendLayout();
            // 
            // btnOpenList
            // 
            btnOpenList.Location = new Point(311, 115);
            btnOpenList.Name = "btnOpenList";
            btnOpenList.Size = new Size(175, 29);
            btnOpenList.TabIndex = 0;
            btnOpenList.Text = "View Applicant List";
            btnOpenList.UseVisualStyleBackColor = true;
            btnOpenList.Click += btnOpenList_Click_1;
            // 
            // btnOpenScreening
            // 
            btnOpenScreening.Location = new Point(311, 150);
            btnOpenScreening.Name = "btnOpenScreening";
            btnOpenScreening.Size = new Size(175, 29);
            btnOpenScreening.TabIndex = 1;
            btnOpenScreening.Text = "Applicants";
            btnOpenScreening.UseVisualStyleBackColor = true;
            btnOpenScreening.Click += btnOpenScreening_Click_1;
            // 
            // btnOpenInterview
            // 
            btnOpenInterview.Location = new Point(311, 185);
            btnOpenInterview.Name = "btnOpenInterview";
            btnOpenInterview.Size = new Size(175, 29);
            btnOpenInterview.TabIndex = 2;
            btnOpenInterview.Text = "Schedule Interviews";
            btnOpenInterview.UseVisualStyleBackColor = true;
            btnOpenInterview.Click += btnOpenInterview_Click_1;
            // 
            // btnOpenEvaluation
            // 
            btnOpenEvaluation.Location = new Point(311, 222);
            btnOpenEvaluation.Name = "btnOpenEvaluation";
            btnOpenEvaluation.Size = new Size(175, 29);
            btnOpenEvaluation.TabIndex = 3;
            btnOpenEvaluation.Text = "Open Evaluation";
            btnOpenEvaluation.UseVisualStyleBackColor = true;
            btnOpenEvaluation.Click += btnOpenEvaluation_Click;
            // 
            // btnOpenReview
            // 
            btnOpenReview.Location = new Point(314, 259);
            btnOpenReview.Name = "btnOpenReview";
            btnOpenReview.Size = new Size(172, 29);
            btnOpenReview.TabIndex = 4;
            btnOpenReview.Text = "Review Applications";
            btnOpenReview.UseVisualStyleBackColor = true;
            btnOpenReview.Click += btnOpenReview_Click;
            // 
            // MainDashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnOpenReview);
            Controls.Add(btnOpenEvaluation);
            Controls.Add(btnOpenInterview);
            Controls.Add(btnOpenScreening);
            Controls.Add(btnOpenList);
            Name = "MainDashboard";
            Text = "MainDashboard";
            ResumeLayout(false);
        }

        #endregion

        private Button btnOpenList;
        private Button btnOpenScreening;
        private Button btnOpenInterview;
        private Button btnOpenEvaluation;
        private Button btnOpenReview;
    }
}